<?php
require_once 'config.php';
require_once 'includes/auth.php';
checkLogin();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $quantity = (int)$_POST['quantity'];
    $unit = $conn->real_escape_string($_POST['unit']);
    $description = $conn->real_escape_string($_POST['description']);

    if (empty($name) || empty($category) || empty($unit)) {
        $error = "Nama, Kategori, dan Satuan wajib diisi!";
    } else {
        $sql = "INSERT INTO items (name, category, quantity, unit, description) VALUES ('$name', '$category', $quantity, '$unit', '$description')";
        if ($conn->query($sql)) {
            $success = "Barang berhasil ditambahkan!";
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card card-custom">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Tambah Barang Baru</h5>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" name="name" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="category" required>
                                <option value="">Pilih Kategori</option>
                                <option value="Kabel Drop Core">Kabel Drop Core</option>
                                <option value="Kabel Fiber Optik">Kabel Fiber Optik</option>
                                <option value="Modem ONT">Modem ONT</option>
                                <option value="Router">Router</option>
                                <option value="Konektor">Konektor (Fast Connector)</option>
                                <option value="ODP">ODP (Optical Distribution Point)</option>
                                <option value="Lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Satuan</label>
                            <input type="text" class="form-control" name="unit" placeholder="Pcs, Meter, Box, dll" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jumlah Stok</label>
                        <input type="number" class="form-control" name="quantity" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Keterangan</label>
                        <textarea class="form-control" name="description" rows="3"></textarea>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="index.php" class="btn btn-secondary">Kembali</a>
                        <button type="submit" class="btn btn-primary">Simpan Barang</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
