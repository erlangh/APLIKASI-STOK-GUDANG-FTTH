</div> <!-- End Container -->

<footer class="footer mt-auto py-3 bg-light">
  <div class="container text-center">
    <span class="text-muted">© <?php echo date('Y'); ?> PT. Konektivitas Digital Kalimantan. All rights reserved.</span>
  </div>
</footer>

<!-- Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
