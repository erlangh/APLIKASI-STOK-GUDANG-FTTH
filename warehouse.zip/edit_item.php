<?php
require_once 'config.php';
require_once 'includes/auth.php';
checkLogin();

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id = (int)$_GET['id'];
$sql = "SELECT * FROM items WHERE id = $id";
$result = $conn->query($sql);

if ($result->num_rows == 0) {
    header("Location: index.php");
    exit();
}

$row = $result->fetch_assoc();
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $category = $conn->real_escape_string($_POST['category']);
    $quantity = (int)$_POST['quantity'];
    $unit = $conn->real_escape_string($_POST['unit']);
    $description = $conn->real_escape_string($_POST['description']);

    if (empty($name) || empty($category) || empty($unit)) {
        $error = "Nama, Kategori, dan Satuan wajib diisi!";
    } else {
        $sql_update = "UPDATE items SET name='$name', category='$category', quantity=$quantity, unit='$unit', description='$description' WHERE id=$id";
        if ($conn->query($sql_update)) {
            $success = "Barang berhasil diperbarui!";
            // Refresh data
            $result = $conn->query($sql);
            $row = $result->fetch_assoc();
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

require_once 'includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card card-custom">
            <div class="card-header bg-warning">
                <h5 class="mb-0">Edit Barang</h5>
            </div>
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Nama Barang</label>
                        <input type="text" class="form-control" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="category" required>
                                <option value="Kabel Drop Core" <?php if($row['category'] == 'Kabel Drop Core') echo 'selected'; ?>>Kabel Drop Core</option>
                                <option value="Kabel Fiber Optik" <?php if($row['category'] == 'Kabel Fiber Optik') echo 'selected'; ?>>Kabel Fiber Optik</option>
                                <option value="Modem ONT" <?php if($row['category'] == 'Modem ONT') echo 'selected'; ?>>Modem ONT</option>
                                <option value="Router" <?php if($row['category'] == 'Router') echo 'selected'; ?>>Router</option>
                                <option value="Konektor" <?php if($row['category'] == 'Konektor') echo 'selected'; ?>>Konektor (Fast Connector)</option>
                                <option value="ODP" <?php if($row['category'] == 'ODP') echo 'selected'; ?>>ODP (Optical Distribution Point)</option>
                                <option value="Lainnya" <?php if($row['category'] == 'Lainnya') echo 'selected'; ?>>Lainnya</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Satuan</label>
                            <input type="text" class="form-control" name="unit" value="<?php echo htmlspecialchars($row['unit']); ?>" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jumlah Stok</label>
                        <input type="number" class="form-control" name="quantity" min="0" value="<?php echo $row['quantity']; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Keterangan</label>
                        <textarea class="form-control" name="description" rows="3"><?php echo htmlspecialchars($row['description']); ?></textarea>
                    </div>
                    <div class="d-flex justify-content-between">
                        <a href="index.php" class="btn btn-secondary">Kembali</a>
                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
